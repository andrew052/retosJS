let form=document.getElementById("formulario")
let fe1=document.querySelector("#e1 .feedback")
let fe2=document.querySelector("#e2 .feedback")
let fe3=document.querySelector("#e3 .feedback")
let fe4=document.querySelector("#e4 .feedback")
let fe5=document.querySelector("#e5 .feedback")
const $number=/^[0-9]{1,15}/
const $text=/^[A-Z a-záÁñÑ]{1,50}/
const $email=/^[A-Z a-záÁñÑ@]{1,50}/

form.noDoc.addEventListener("input",(e)=>{
    e.preventDefault();
    if($number.test(e.target.value)){
     form.noDoc.setAttribute("classs","success")
        fe1.style.setProperty("opacity","1")
        fe1.style.setProperty("visibility","hidden")
    }
    else{
        form.noDoc.setAttribute("class","error")
        fe1.textContent="la longitud minima es de uno"
        fe1.style.setProperty("opacity","1")
        fe1.style.setProperty("visibility","visible")
    }
})
form.nombre.addEventListener("input",(e)=>{
    e.preventDefault();
    if ($text.test(e.target.value)) {
        form.nombre.setAttribute("class","success")  
        fe2.style.setProperty("opacity","1")
        fe2.style.setProperty("visibility","hidden")  
    } else {
        form.nombre.setAttribute("class","error")
        fe2.textContent("la longitud minima es de uno")
        fe2.style.setProperty("opacity","1")
        fe2.style.setProperty("visibility","visible")
    }
})
form.apellido.addEventListener("input",(e)=>{
    e.preventDefault();
    if ($text.test(e.target.value)) {
        form.apellido.setAttribute("class","success")  
        fe3.style.setAttribute("opacity","1")
        fe3.style.setAttribute("visibility","hidden")  
    } else {
        form.apellido.setAttribute("class","error")
        fe3.textContent("la longitud minima es de uno")
        fe3.style.setAttribute("opacity","1")
        fe3.style.setAttribute("visibility","visible")
    }
})
form.email.addEventListener("input",(e)=>{
    e.preventDefault();
    if ($email.test(e.target.value)) {
        form.email.setAttribute("class","success")  
        fe4.style.setAttribute("opacity","1")
        fe4.style.setAttribute("visibility","hidden")  
    } else {
        form.email.setAttribute("class","error")
        fe4.textContent("la longitud minima es de uno")
        fe4.style.setAttribute("opacity","1")
        fe4.style.setAttribute("visibility","visible")
    }
})
form.telefono.addEventListener("input",(e)=>{
    e.preventDefault();
    if($number.test(e.target.value)){
    form.telefono.setAttribute("class","success")  
        fe5.style.setAttribute("opacity","1")
        fe5.style.setAttribute("visibility","hidden")
    }
    else{
        form.telefono.setAttribute("class","error")
        fe5.textContent("la longitud minima es de uno")
        fe5.style.setAttribute("opacity","1")
        fe5.style.setAttribute("visibility","visible")
    }
})

form.addEventListener("submit", (e)=>{
    e.preventDefault()

    const noDoc=form.noDoc.value;

    if (noDoc==null ||  noDoc==0) {
        alert ("el campo No documento esta vacio")
        form.noDoc.focus();
        form.noDoc.setAttribute("class", "error")
        
    }
    else{
        form.onsubmit()
        alert("datos enviados")
    }
})


form.addEventListener("submit", (e)=>{
    e.preventDefault()

    const nombre=form.nombre.value;

    if (nombre==null ||  nombre==0) {
        alert ("el campo nombre esta vacio")
        form.nombre.focus();
        form.nombre.setAttribute("class", "error")
        
    }
    else{
        form.onsubmit()
        alert("datos enviados")
    }
})


form.addEventListener("submit", (e)=>{
    e.preventDefault()

    const apellido=form.apellido.value;

    if (apellido==null ||  apellido==0) {
        alert ("el campo apellido esta vacio")
        form.apellido.focus();
        form.apellido.setAttribute("class", "error")
        
    }
    else{
        form.onsubmit()
        alert("datos enviados")
    }
})

form.addEventListener("submit", (e)=>{
    e.preventDefault()

    const email=form.email.value;

    if (email==null ||  email==0) {
        alert ("el campo esta vacio en el correo")
        form.email.focus();
        form.email.setAttribute("class", "error")
        
    }
    else{
        form.onsubmit()
        alert("datos enviados")
    }
})

form.addEventListener("submit", (e)=>{
    e.preventDefault()

    const telefono=form.telefono.value;

    if (telefono==null ||  telefono==0) {
        alert ("el campo esta vacio en el telefono")
        form.telefono.focus();
        form.telefono.setAttribute("class", "error")
        
    }
    else{
        form.onsubmit()
        alert("datos enviados")
    }
})
